package producao;
  
public interface EmbaralhadorDePalavras {
	
 public String embaralharPalavra(String palavra);
 public double getFatorDePontuacao();
 
}
